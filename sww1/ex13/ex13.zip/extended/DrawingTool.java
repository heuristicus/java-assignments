package ex13.extended;

public class DrawingTool {

    /**
     * Creates a new DrawingFrame and shows it on the screen.
     * @param args
     */
    public static void main(String args[]) {
        DrawingFrame r;
        r = new DrawingFrame(600, 400);
        r.setVisible(true);

    }
}
